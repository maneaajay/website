import React from 'react'
import Howitwork from '../Howitwork'
import Navbar from '../Navbar'
import Footer from '../Footer'
const Service = () => {
    return (
        <>
             
             <Howitwork/>
             <Footer/>
        </>
    )
}

export default Service

import React from 'react'
import Error404 from '../Error404'

const Error = () => {
    return (
        <>
            <Error404></Error404>
        </>
    )
}

export default Error

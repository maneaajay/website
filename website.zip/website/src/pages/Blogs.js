import React from 'react'
import Blog from '../Blog'
import Navbar from '../Navbar'
import Footer from '../Footer'
const Blogs = () => {
    return (
        <>
             
             <Blog/>
             <Footer/> 
        </>
    )
}

export default Blogs

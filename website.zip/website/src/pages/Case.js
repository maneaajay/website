import React from 'react'
import Casestudy from '../Casestudy'
import Navbar from '../Navbar'
import Footer from '../Footer'
const Case = () => {
    return (
        <>
            
           
             <Casestudy/>
             <Footer/> 
        </>
    )
}

export default Case

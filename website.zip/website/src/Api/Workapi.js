const Workapi=[
{
    id:1,
    logo:"fas fa-chart-line",
    title:"DATA ANALYST",
    info:" Descriptive, diagnostic, predictive, and prescriptive. ",
},
{
    id:2,
    logo:"fab fa-microsoft",
    title:"AZURE SYNAPES",
    info:" limitless analytics service ",
},
{
    id:3,
    logo:"fab fa-aws",
    title:"AWS CLOUD SERVICES",
    info:" Creating Intuitive Interfaces ",
},
{
    
    id:4,
    logo:"fas fa-desktop",
    title:"WEB DEVELOPMENT",
    info:" Each Line of Code is Refined",
},
{
    
    id:5,
    logo:"fas fa-mobile-alt",
    title:"MOBILE APP DEVELOPMENT",
    info:" Unique and Feature-Rich Apps",
},
{
    id:6,
    logo:"fas fa-database",
    title:"DATABASE",
    info:" customer profiles and marketing activities.",
}
];

export default Workapi;
const Caseapi=[
    {
        id:1,
        b_img:"./images/sound.jpg",
        b_title:"What Is Sound?",
        b_description:" Sound is a pressure wave that is created by a vibrating object. These vibrations set particles in the surrounding medium in vibrational motion, thus transporting energy through the medium. Mediums are solid, liquid",
    },
    {
        id:2,
        b_img:"./images/sql.jpg",
        b_title:"SQL - Get Started with SQL using Python",
        b_description:" SQL is a mandatory language every analyst and data Science professional should know.Learn about the basics of SQL here, including how to work with SQLite database using python.",
    },

]

export default Caseapi;